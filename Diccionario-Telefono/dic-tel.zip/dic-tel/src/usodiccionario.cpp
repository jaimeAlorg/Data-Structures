#include <iostream>
#include <fstream>
#include "diccionario.h"


/*Recorre la lista de información asociada a una clave y la imprime*/
void EscribeSigni(const list<string>&l){		 
	  list<string>::const_iterator it_s;
	  
	  for (it_s=l.begin();it_s!=l.end();++it_s){
		    cout<<*it_s<<endl;
	  }
}	


/*Lee un diccioario e imprime datos asociados a una clave. 
Hay un fichero ejemplo de prueba: data.txt.Para lanzar el programa con ese fichero se escribe: 
                  ./usodiccionario < data.txt 
*/


int main(){
 Diccionario<string,string> D;

cin>>D;
cout<<D;

string a;

cout<<"Introduce una palabra"<<endl;
cin>>a;

bool eliminarUlt;
bool eliminarPrim;

string clave = "Sentencia";
eliminarUlt = D.borrarUltimoSigni(clave);

if(eliminarUlt == true){
	cout << "\nEl ultimo significado de la palabra " << clave << " se ha eliminado correctamente" << endl;
	cout << D;
}else{
	cout << "\nLa palabra " << clave << " no existe" << endl;
}

eliminarPrim = D.borrarPrimerSigni(clave);

if(eliminarUlt == true){
	cout << "\nEl primer significado de la palabra " << clave << " se ha eliminado correctamente" << endl;
	cout << D;
}else{
	cout << "\nLa palabra " << clave << " no existe" << endl;
}

list<string>l=D.getInfo_Asoc(a);

if (l.size()>0)
	  EscribeSigni(l);
}
