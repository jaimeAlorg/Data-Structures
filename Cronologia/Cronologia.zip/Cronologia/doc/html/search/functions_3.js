var searchData=
[
  ['fecha_5fhistorica_26',['Fecha_Historica',['../class_fecha___historica.html#a17514fb90833c1446a0e8e824833bc40',1,'Fecha_Historica::Fecha_Historica()'],['../class_fecha___historica.html#a4f0007b89c89b2fbb3b1a0df936f8f20',1,'Fecha_Historica::Fecha_Historica(int a, string *s, int n)'],['../class_fecha___historica.html#a22a72d1bcd6d7e28ca5d33811edc9010',1,'Fecha_Historica::Fecha_Historica(const Fecha_Historica &amp;e)']]]
];
