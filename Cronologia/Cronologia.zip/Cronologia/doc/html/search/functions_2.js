var searchData=
[
  ['copiar_24',['copiar',['../class_fecha___historica.html#a51883df908443ced5672fdd475ab6f58',1,'Fecha_Historica']]],
  ['cronologia_25',['Cronologia',['../class_cronologia.html#ac0026b1919148f6cd6cf4ca4c357771e',1,'Cronologia::Cronologia()'],['../class_cronologia.html#aac1b1377e201567ac98dd92e74c7b3cc',1,'Cronologia::Cronologia(Fecha_Historica *eh, int n)'],['../class_cronologia.html#a35694d459c7f2bc902b8db6abf13662d',1,'Cronologia::Cronologia(const Cronologia &amp;c)']]]
];
