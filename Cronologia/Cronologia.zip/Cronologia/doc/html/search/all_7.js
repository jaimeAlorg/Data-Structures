var searchData=
[
  ['rep_20del_20tda_20cronologia_13',['Rep del TDA Cronologia',['../rep_conjunto.html',1,'']]],
  ['reservar_14',['Reservar',['../class_fecha___historica.html#a0c0e7e0af35375fb9029306d03eaac42',1,'Fecha_Historica']]]
];
