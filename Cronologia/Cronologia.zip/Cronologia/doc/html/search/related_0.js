var searchData=
[
  ['operator_3c_3c_33',['operator&lt;&lt;',['../class_cronologia.html#a5a590e2ec95cc4489c3de5b03e2cac4c',1,'Cronologia::operator&lt;&lt;()'],['../class_fecha___historica.html#a7d8feb850ce61911b1860250055c5573',1,'Fecha_Historica::operator&lt;&lt;()']]],
  ['operator_3e_3e_34',['operator&gt;&gt;',['../class_cronologia.html#a6fa0f1131309b1cee355b9d8297ea33d',1,'Cronologia::operator&gt;&gt;()'],['../class_fecha___historica.html#a33544bb59ebbf85043c0ce14eb3f16fa',1,'Fecha_Historica::operator&gt;&gt;()']]]
];
