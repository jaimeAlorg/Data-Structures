var searchData=
[
  ['buscaranio_22',['buscarAnio',['../class_cronologia.html#a3c58e5cdc7f30c4f09742366497563f4',1,'Cronologia']]],
  ['buscareventos_23',['buscarEventos',['../class_cronologia.html#a8689dd8e02dbb9679f6fea4bf94b9813',1,'Cronologia::buscarEventos()'],['../class_fecha___historica.html#ac741b615be172d79546cd748a0a6526d',1,'Fecha_Historica::buscarEventos()']]]
];
