var searchData=
[
  ['aniadirevento_21',['aniadirEvento',['../class_cronologia.html#af6f0f63bb2e2e19f2d03bf9cef81e7c5',1,'Cronologia::aniadirEvento()'],['../class_fecha___historica.html#a2598ec5250c77d90580df113011d4208',1,'Fecha_Historica::aniadirevento()']]]
];
