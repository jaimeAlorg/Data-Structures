var searchData=
[
  ['operator_3d_29',['operator=',['../class_cronologia.html#a317a0799fe377ae78c5991f1f048936b',1,'Cronologia::operator=()'],['../class_fecha___historica.html#a9ddcb6bd988f470756109015a9aad8d6',1,'Fecha_Historica::operator=()']]]
];
