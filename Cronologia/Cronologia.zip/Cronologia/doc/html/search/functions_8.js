var searchData=
[
  ['_7ecronologia_31',['~Cronologia',['../class_cronologia.html#a7e995892e46a00b54d70a905e2bdbc53',1,'Cronologia']]],
  ['_7efecha_5fhistorica_32',['~Fecha_Historica',['../class_fecha___historica.html#a71b1bcf8df8300beaef6143ea10d5aff',1,'Fecha_Historica']]]
];
