#include <iostream>
#include "Fecha_Historica.h"

using namespace std;

//Resize simple
void Fecha_Historica::resize(int r)
{
  string *aux = new string[r];
  for (int i = 0; i < numeventos; ++i)
  {
    aux[i] = str[i];
  }
  delete[] str;
  str = aux;
  reservados = r;
}

//Constructor vacío
Fecha_Historica::Fecha_Historica() : anio(0), reservados(0), numeventos(0), str(0) {}

//Constructor con parametros año, cadena de eventoentos y número de eventoentos a añadir
Fecha_Historica::Fecha_Historica(int a, string *s, int n) : reservados(n), numeventos(n)
{
  assert(a >= 0 && a <= 9999);
  anio = a;
  string *str = new string[n];
  for (int i = 0; i < n; i++)
    str[i] = s[i];
}

//Constructor de copias
Fecha_Historica::Fecha_Historica(const Fecha_Historica &e)
{
  str = new string[e.reservados];
  anio = e.anio;
  numeventos = e.numeventos;
  reservados = e.numeventos;
  for (int i = 0; i < numeventos; ++i)
    str[i] = e.str[i];
}

//Método de acceso a año
int Fecha_Historica::getAnio()
{
  return anio;
}

//Añade un eventoento
void Fecha_Historica::aniadirevento(string &eventoent)
{
  if (numeventos == reservados)
  {
    if (numeventos == 0)
      resize(1);
    else
      resize(2 * reservados);
  }
  str[numeventos] = eventoent;
  numeventos++;
}

//Buscador de eventoentos
bool Fecha_Historica::buscarEventos(string s, Fecha_Historica &matches)
{
  bool encontrado = false;
  for (int i = 0; i < numeventos; ++i)
  {
    if (str[i].find(s) != -1)
    {
      matches.aniadirevento(str[i]);
      encontrado = true;
    }
  }
  if (encontrado)
  {
    matches.anio = anio;
  }
  return encontrado;
}

void Fecha_Historica::Reservar(int r)
{
  if (r < 0)
  {
    reservados = 0;
  }
  else
  {
    reservados = r;
  }
  str = new string[reservados];
}

void Fecha_Historica::Liberar()
{
  anio = 0;
  numeventos = 0;
  reservados = 0;
  delete[] str;
}

void Fecha_Historica::copiar(string *s, int r, int evento)
{
  assert(evento <= r);
  numeventos = evento;
  Reservar(r);

  for (int i = 0; i < numeventos; i++)
    str[i] = s[i];
}

Fecha_Historica &Fecha_Historica::operator=(const Fecha_Historica &e)
{
  if (this != &e)
  {
    anio = e.anio;
    copiar(e.str, e.reservados, e.numeventos);
  }
  return *this;
}

//Operador <<
ostream &operator<<(ostream &os, const Fecha_Historica &e)
{
  char h = '#';
  os << e.anio;

  for (int i = 0; i < e.numeventos; i++)
  {
    os << h << e.str[i];
  }

  os << endl;

  return os;
}

//Operador >>
istream &operator>>(istream &is, Fecha_Historica &e)
{
  char h;
  string evento;
  int cont = 1, cont2 = 0;

  e.Liberar();

  is >> e.anio >> h;
  getline(is, evento);

  //PARA VER CUANTOS EVENTOS HAY EN UN AÑO
  for (int i = 0; i < evento.size(); i++)
  {
    if (evento[i] == '#')
    {
      cont++;
    }
  }

  string *aux = new string[cont];

  //COGE LOS EVENTOS DE CADA AÑO
  for (int i = 0; i < evento.size(); i++)
  {
    if (evento[i] == '#')
    {
      cont2++;
    }
    else
    {
      aux[cont2].push_back(evento[i]);
    }
  }

  //RESERVAMOS
  e.Reservar(cont);

  //METE LOS EVENTOS DE CADA AÑO
  for (int i = 0; i < cont; i++)
  {
    e.aniadirevento(aux[i]);
  }

  //LIBERAMOS
  delete[] aux;

  return is;
}
