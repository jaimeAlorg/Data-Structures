/**
 * @file usopilas_max.cpp
 * @author Jaime Álvarez Orgaz
*/

#include <iostream>
#include "Pila_max_VD.h"

using namespace std;

int main()
{
	//EN ESTE MAIN SE COMPRUEBA QUE FUNCIONAN LOS MÉTODOS DE LA CLASE PILA_MAX_VD

	Pila_Max_VD p;
	
	for(int i = 1; i < 10; i++){
		p.poner(i);
		cout << p.tope();
	}
	
 	while(!p.vacia()){
 		cout<<p.tope();
 		p.quitar();
 	}
	 
	return 0;
}
