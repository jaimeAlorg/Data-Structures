/**
  * @file Pila_Max_VD.cpp
  * @brief Implementaci�n del TDA Pila
  *
  */

Pila_Max_VD::~Pila_Max_VD(){
    datos.~VectorDinamico();
}


Pila_Max_VD& Pila_Max_VD::operator=(const Pila_Max_VD & orig){
    if(this != &orig){
        datos = orig.datos;
    }
    
    return *this;
}

bool Pila_Max_VD::vacia() const{
    bool ret = true;
    
    if(datos.dimension() != 0){
      ret = false;
    }

    return ret;
}

Elemento Pila_Max_VD::tope(){
    return datos.ultElem();
}

void Pila_Max_VD::poner(int num){
    Elemento aux;
    aux.ele = num;

    if(num > tope().max){
        aux.max = num;
    }else{
        aux.max = tope().max;
    }

    datos.asignar_componente(datos.dimension(), aux);
}

void Pila_Max_VD::quitar(){
    datos.eliminarUlt();
}

int Pila_Max_VD::getNumElementos() const{
    return datos.dimension();
};




