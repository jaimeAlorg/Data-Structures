var searchData=
[
  ['getnumelementos_5',['getNumElementos',['../class_pila___max___v_d.html#afd0f3a173b0fb73cace0bec4b4a9bb54',1,'Pila_Max_VD']]]
];
