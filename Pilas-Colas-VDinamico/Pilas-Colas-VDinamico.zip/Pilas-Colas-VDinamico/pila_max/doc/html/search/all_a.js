var searchData=
[
  ['ultelem_15',['ultElem',['../class_vector_dinamico.html#a92e74ea714763888034adf0e3d6d8610',1,'VectorDinamico']]],
  ['usopilas_5fmax_2ecpp_16',['usopilas_max.cpp',['../usopilas__max_8cpp.html',1,'']]]
];
