var searchData=
[
  ['quitar_12',['quitar',['../class_pila___max___v_d.html#a761d7edcf2fe4a2414038ca31eb1ae75',1,'Pila_Max_VD']]]
];
