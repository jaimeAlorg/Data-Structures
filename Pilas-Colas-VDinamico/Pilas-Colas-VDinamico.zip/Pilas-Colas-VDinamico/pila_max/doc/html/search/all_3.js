var searchData=
[
  ['elemento_3',['Elemento',['../struct_elemento.html',1,'']]],
  ['eliminarult_4',['eliminarUlt',['../class_vector_dinamico.html#a9c4cdf6aafd9d86a62ae46ff34eaf794',1,'VectorDinamico']]]
];
