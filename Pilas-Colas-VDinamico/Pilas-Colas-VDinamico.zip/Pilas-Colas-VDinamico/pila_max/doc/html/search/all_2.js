var searchData=
[
  ['dimension_2',['dimension',['../class_vector_dinamico.html#a52e08b5e5c6e74fa739cc95a19993919',1,'VectorDinamico']]]
];
