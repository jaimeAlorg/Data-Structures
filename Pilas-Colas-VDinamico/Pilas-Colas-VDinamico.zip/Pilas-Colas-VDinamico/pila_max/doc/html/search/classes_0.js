var searchData=
[
  ['elemento_22',['Elemento',['../struct_elemento.html',1,'']]]
];
