/**
  * @file Pila_max_VD.h
  * @brief Fichero cabecera del TDA Pila Max Vector Dinamico
  *
  * Se crea un vector con capacidad de crecer y decrecer
  * 
  */

#ifndef Pila_Max_VD_H
#define Pila_Max_VD_H
#include "VDG.h"

#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

/**
 *  @brief T.D.A. Pila_Max_VD
 *  TDA Pila con VD.
 *  @author Jaime Álvarez Orgaz
 * 
 */


struct Elemento{
    int ele;
    int max;
};

ostream& operator <<(ostream &os, const Elemento &elem){
    os << " Elemento " << elem.ele << " MAX: " << elem.max << endl;
    return os;
}

class Pila_Max_VD{
    private:
        VectorDinamico<Elemento> datos;
    public:
        /**
        * @brief Constructor por defecto. Usa el constructor del VD.
        */
        Pila_Max_VD(){};

        /**
        * @brief Constructor de copias
        * @param orig La pila de la que se hara la copia.
        */
        Pila_Max_VD(const Pila_Max_VD& orig):datos(orig.datos){};
        
        /**
        * @brief Destructor. Usa el constructor del VD.
        */
        ~Pila_Max_VD();

        /**
        * @brief Operador de asignación
        * @param orig La pila que se va a asignar.
        */
        Pila_Max_VD& operator=(const Pila_Max_VD& orig);

        /**
        * @brief Comprueba si la pila est� vac�a
        */
        bool vacia() const;

        /**
         * @brief Devuelve el Elemento del tope de la pila
         */
        Elemento tope();

        /**
        * @brief A�ade un Elemento "encima" del tope de la pila
        * @param elem Elemento que se va a a�adir.
        */
        void poner(int elem);

        /**
        * @brief Quita el Elemento del tope de la pila
        */
        void quitar();

        /**
        * @brief Devuelve el n�mero de Elementos de la pila
        */
        int getNumElementos() const;
};

#include <../src/Pila_max_VD.cpp>
#endif 