var searchData=
[
  ['diccionario_6',['Diccionario',['../class_diccionario.html',1,'Diccionario'],['../class_diccionario.html#aa0a2191ec706b256c35b5229cc197b15',1,'Diccionario::Diccionario()']]]
];
