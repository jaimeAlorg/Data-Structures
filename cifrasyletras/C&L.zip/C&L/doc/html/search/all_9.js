var searchData=
[
  ['palabraslongitud_29',['palabrasLongitud',['../class_diccionario.html#a7761bcb623775550e7bb19a0e28d03a4',1,'Diccionario']]]
];
