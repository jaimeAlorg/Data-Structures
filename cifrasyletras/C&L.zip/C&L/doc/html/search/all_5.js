var searchData=
[
  ['generarsoll_10',['generarSolL',['../class_conjunto___letras.html#a25feddcfa43ad28e6a6f73e3efafb21b',1,'Conjunto_Letras']]],
  ['generarsolpt_11',['generarSolPT',['../class_conjunto___letras.html#a7bbc914028514cc8403dc2e180811484',1,'Conjunto_Letras']]],
  ['getcaracter_12',['getCaracter',['../class_letra.html#af64f6b0f46cde3a70ef9a8e1afb4c1de',1,'Letra']]],
  ['getconjunto_13',['getConjunto',['../class_conjunto___letras.html#a82960adba7c64ae5cc26e5b24fa255df',1,'Conjunto_Letras']]],
  ['getnumapariciones_14',['getNumApariciones',['../class_letra.html#a981e965a8b0a11794ea9b9847574db46',1,'Letra']]],
  ['getpuntuacion_15',['getPuntuacion',['../class_conjunto___letras.html#ae42f71d0c47e0291029108183aabc240',1,'Conjunto_Letras::getPuntuacion()'],['../class_letra.html#a69fbe0f8c7eb41d3451b53372add22d7',1,'Letra::getPuntuacion()']]]
];
