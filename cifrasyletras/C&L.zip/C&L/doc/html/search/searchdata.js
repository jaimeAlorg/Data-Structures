var indexSectionsWithContent =
{
  0: "abcdegilops~",
  1: "bcdil",
  2: "abcdegilops~",
  3: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "related"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Funciones",
  3: "Amigas"
};

