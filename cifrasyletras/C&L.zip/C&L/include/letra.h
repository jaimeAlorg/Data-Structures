#ifndef _LETRA_H
#define _LETRA_H
#include <fstream>
#include <iostream>
using namespace std;

class Letra{
    private:
        char caracter;
        int num_apariciones;
        int puntuacion;
    public:

        /**
        @brief Construye una Letra vacía.
        **/
        Letra();

        /**
        @brief Construye una Letra.
        @param c Caracter
        @param n Numero de apariciones
        @param p Puntuación
        **/
        Letra(char c, int n, int p);

        /**
        @brief Construye una Letra a partir de otra.
        @param orig Otra letra
        **/
        Letra(const Letra &orig);

        /**
        @brief Libera una letra
        **/
        void Liberar();

        /**
        @brief Destruye una letra
        **/
        ~Letra();

        /**
        @brief Operador = de Letra
        @param orig Una letra
        @return Devuelve una letra
        **/
        Letra &operator=(const Letra &orig);

        /**
        @brief Consultor del caracter.
        @return Devuelve un caracter
        **/
        char getCaracter()const;

        /**
        @brief Consultor del número de apariciones.
        @return Devuelve el número de apariciones de un caracter
        **/
        int getNumApariciones()const;

        /**
        @brief Consultor de la puntuacion.
        @return Devuelve la puntuación de un caracter
        **/
        int getPuntuacion()const;

        /**
        @brief Modificador de un caracter
        @param c Caracter
        **/
        void setCaracter(char c);

        /**
        @brief Modificador del numero de apariciones
        @param n numero de apariciones
        **/
        void setNumApariciones(int n);

        /**
        @brief Modificador de la puntuación
        @param p puntuacion
        **/
        void setPuntuacion(int p);

        /**
        @brief Operador <
        @param l letra
        @return true si se cumple
        **/
        bool operator<(const Letra &l) const;

        /**
        @brief Lee de un flujo de entrada una letra
        @param is:flujo de entrada
        @param otro: el objeto donde se realiza la lectura.
        @return el flujo de entrada
        **/
        friend istream& operator>>(istream &is, Letra &otro);

        /**
        @brief Escribe en un flujo de salida una letra
        @param os:flujo de salida
        @param orig: el objeto diccionario que se escribe
        @return el flujo de salida
        **/
        friend ostream& operator<<(ostream &os, const Letra &orig);
};

#endif 