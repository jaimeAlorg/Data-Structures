#ifndef _CONJUNTO_LETRAS_H
#define _CONJUNTO_LETRAS_H
#include "letra.h"
#include "diccionario.h"
#include <set>
#include <string>
#include <vector>
#include <iostream>

using namespace std;

class Conjunto_Letras
{
private:
    set<Letra> conjunto;

public:
    /**
    @brief Construye un Conjunto de Letras vacio.
    **/
    Conjunto_Letras();

    /**
    @brief Construye un Conjunto de Letras a partir de otro.
    @param orig Otro conjunto de letras
    **/
    Conjunto_Letras(const Conjunto_Letras &orig);

    /**
    @brief Libera un conjunto de Letras
    **/

   void liberar();

    /**
    @brief Destructor de un conjunto de letras
    **/
    ~Conjunto_Letras();

    /**
    @brief Operador = para la clase Conjunto_Letras
    @param otro Otro conjunto de letras
    **/
    Conjunto_Letras &operator=(const Conjunto_Letras &otro);

    /**
    @brief Método para obtener la puntuación de una letra del conjunto
    @param letra Letra que se le pasa para obtener la puntuación
    @return Devuelve la puntuación de una letra del conjunto
    **/
    int getPuntuacion(char letra) const;

    /**
    @brief Método para obtener un conjunto de letras
    @return Devuelve un conjunto de letras
    **/
    set<Letra> getConjunto() const;

    /**
    @brief Inserta una letra en el conjunto
    @param l Una letra para insertar;
    **/
    void insertar(Letra l);

    /**
    @brief Elimina una letra del conjunto
    @param l Una letra para eliminar;
    **/
    void eliminar(Letra l);

    /**
    @brief Método el cual devuelve true si la palabra que se le pasa es correcta acorde con las letras que se le pasa
    @param string Palabra que se le pasa;
    @param letras Letras con las que tiene que estar formada la palabra
    @return Devuelve true si la palabra esa formada con las letras
    **/
    bool Correcta(string palabra, string letras);

    /**
    @brief Método el cual genera una solución para el problema de las letras por longitud
    @param dic Diccionario que se le pasa
    @param l Conjunto de letras que se le pasa
    @param tam Tamaño de la palabra maximo.
    @return Devuelve la mejor solución y imprimer todas las soluciones con mejor longitud
    **/
    string generarSolL(const Diccionario &dic, string l, int tam);

    /**
    @brief Calcula la puntuación
    @param palabra Palabra que se le pasa para calcular la puntuación
    @param c Conjunto de letras que se le pasa
    @return Devuelve la puntuación de una palabra
    **/
    int calculaPuntos(string palabra, const Conjunto_Letras &c);

    /**
    @brief Método el cual genera una solución para el problema de las letras por puntuación
    @param dic Diccionario que se le pasa
    @param letras Conjunto de letras que se le pasa
    @param tam Tamaño de la palabra maximo.
    @param conj Conjunto de letras.
    @return Devuelve la mejor solución y imprimer todas las soluciones con mejor longitud
    **/
    string generarSolPT(const Diccionario &dic, string letras, int tam,const Conjunto_Letras &conj);
    
    /**
    @brief Lee de un flujo de entrada un conjunto de letras
    @param is:flujo de entrada
    @param otro: el objeto donde se realiza la lectura.
    @return el flujo de entrada
    **/
    friend istream &operator>>(istream &is, Conjunto_Letras &otro);

    /**
    @brief Escribe en un flujo de salida un conjunto de letras
    @param os:flujo de salida
    @param otro: el objeto diccionario que se escribe
    @return el flujo de salida
    **/
    friend ostream &operator<<(ostream &os, Conjunto_Letras &otro);

    typedef set<Letra>::iterator iterator;
    typedef set<Letra>::const_iterator const_iterator;

    /**
    * @brief Begin del iterador de la clase Conjunto Letras
    */
    Conjunto_Letras::iterator begin();

    /**
    * @brief Begin del const_iterador de la clase Conjunto Letras
    */
    Conjunto_Letras::const_iterator begin() const;

    /**
    * @brief End del iterador de la clase Conjunto Letras
    */
    Conjunto_Letras::iterator end();

    /**
    * @brief End del const_iterador de la clase Conjunto Letras
    */
    Conjunto_Letras::const_iterator end() const;
};

#endif