#ifndef _BOLSA_LETRAS_H
#define _BOLSA_LETRAS_H
#include "conjunto_letras.h"
#include <vector>
#include <iostream>

using namespace std;

class Bolsa_Letras{
    private:
        vector<char> bolsa;
    public:

        /**
         * @brief Crea una bolsa vacia;
         */
        Bolsa_Letras();

        /**
         * @brief Crea una bolsa a partir de otra;
         * @param orig Otra bolsa
         */
        Bolsa_Letras(const Bolsa_Letras &orig);

        /**
         * @brief Libera una bolsa
         */
        void Liberar();

        /**
         * @brief Destruye una bolsa
         */
        ~Bolsa_Letras();

        /**
         * @brief Operador = para bolsa de letras
         * @param otro Otra bolsa
         * @return Devuelve una bolsa de letras
         */
        Bolsa_Letras &operator=(const Bolsa_Letras &otro);
        
        /**
         * @brief Saca un número de letras de la bolsa
         * @param n Número de letras para sacar
         * @return Devuelve un string que son las letras que saca
         */
        string sacaLetras(int n);

        /**
         * @brief Añade un conjunto a una bolsa
         * @param conj Conjunto de letras
         */
        void aniadirABolsa(Conjunto_Letras &conj);


};
#endif 