#include <string>
#include "conjunto_letras.h"

Conjunto_Letras::Conjunto_Letras() {
}

Conjunto_Letras::Conjunto_Letras(const Conjunto_Letras &orig){
  conjunto = orig.conjunto;
}

void Conjunto_Letras::liberar(){
  conjunto.clear();
}

Conjunto_Letras::~Conjunto_Letras(){
  liberar();
}

Conjunto_Letras & Conjunto_Letras::operator=(const Conjunto_Letras &otro){
  if(this != &otro){
    conjunto = otro.conjunto;
  }
  
  return *this;
}

int Conjunto_Letras::getPuntuacion(char letra) const
{
  
  Conjunto_Letras::const_iterator it;

  for ( it = begin(); it != end(); ++it)
  {
    if (letra == tolower((*it).getCaracter()))
      return (*it).getPuntuacion();
  }
  return 0;
  
}

set<Letra> Conjunto_Letras::getConjunto() const{
  return conjunto;
}

void Conjunto_Letras::insertar(Letra l){
  conjunto.insert(l);
}

void Conjunto_Letras::eliminar(Letra l){
  conjunto.erase(l);
}

bool Conjunto_Letras::Correcta(string palabra, string letras){
  bool ret = true;

  for(int i = 0; i < palabra.size(); i++){

    if(letras.find(palabra[i]) != string::npos){
      letras.erase(letras.find(palabra[i]),1);

    }else{
       ret = false;
    }
  }

  return ret;
}

string Conjunto_Letras::generarSolL(const Diccionario &dic, string l, int tam){
  int i = tam;
  bool sol = false;
  vector<string> aux;
  string ret;

  for(i; i > 0 && !sol; i--){
    aux = dic.palabrasLongitud(i);

    for(int j = 0; j < aux.size(); j++){
      if(Correcta(aux[j], l)){
        cout << "\nLa palabra: " << aux[j] << " tiene una puntuación de: " << i << " puntos" << endl;
        ret = aux[j];
        sol = true;
      }
    }
  }

  return ret;
}

int Conjunto_Letras::calculaPuntos(string palabra, const Conjunto_Letras &c){
    int puntos=0;

    for(int i=0; i<palabra.size(); i++){
        puntos+=c.getPuntuacion(palabra[i]);
    }
    
    return puntos;
}

string Conjunto_Letras::generarSolPT(const Diccionario &dic, string letras, int tam, const Conjunto_Letras &conj){
    
    int puntuacion, maxpt = 0;
    vector<string> aux;

    Diccionario::const_iterator it;
    vector<string>::const_iterator it2;

    for(it = dic.begin(); it != dic.end(); ++it){
      
        if(Correcta((*it), letras) && (*it).size() <= tam){
            puntuacion = calculaPuntos((*it), conj);

            if(puntuacion == maxpt){
                aux.push_back((*it));

            }else if(puntuacion > maxpt){
                maxpt = puntuacion;
                aux.clear();
                aux.push_back((*it));
            }
        }
    }
    
    for(it2 = aux.begin(); it2 != aux.end(); ++it2){
        cout << "\nPalabra: " << (*it2) << " Puntuacion: " << maxpt;
    }

    return aux.back();
}

istream &operator>>(istream &is, Conjunto_Letras &otro)
{
  Letra l;
  string c;
  is >> c >> c >> c;

  while (is >> l)
  {
    otro.conjunto.insert(l);
  }
  return is;
}

ostream &operator<<(ostream &os, Conjunto_Letras &otro)
{
  os << "#Letra \tCantidad \tPuntos\n";
  Conjunto_Letras::const_iterator it;

  for (it = otro.begin(); it != otro.end(); ++it){
    os << *it;
  }

  return os;
}

Conjunto_Letras::iterator Conjunto_Letras::begin()
{
  return conjunto.begin();
}

Conjunto_Letras::const_iterator Conjunto_Letras::begin() const
{
  return conjunto.begin();
}

Conjunto_Letras::iterator Conjunto_Letras::end()
{
  return conjunto.end();
}

Conjunto_Letras::const_iterator Conjunto_Letras::end() const
{
  return conjunto.end();
}