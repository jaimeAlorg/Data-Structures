#include "diccionario.h"
#include <iostream>

Diccionario::Diccionario(){
}

int Diccionario::size()const{
    return datos.size();
}

vector<string> Diccionario::palabrasLongitud(int longitud)const{
    vector<string> ret;
    string aux;

    set<string>::iterator it;

    for(it = datos.begin(); it != datos.end(); ++it){
        if((*it).size() == longitud){
            aux = (*it);
            ret.push_back(aux);
        }
    }

    return ret;
}

bool Diccionario::Esta(string palabra){
    bool ret = false;
    
    if (size() > 0)
    {
        set<string>::iterator it;

        for (it = datos.begin(); it != datos.end() && ret != true; ++it)
        {
            if ((*it) == palabra)
            {
                ret = true;
            }
        }
    }

    return ret;
}

const string & Diccionario::iterator::operator *(){
  return *it;
}

typename Diccionario::iterator & Diccionario::iterator::operator ++(){
  ++it;
}
typename Diccionario::iterator & Diccionario::iterator::operator --(){
  --it;
}
bool Diccionario::iterator::operator== (const iterator &i){
  return i.it == it;
}
bool Diccionario::iterator::operator!= (const iterator &i){
  return i.it != it;
}

/*
const string & Diccionario::const_iterator::operator *()const{
  return *it;
}

typename Diccionario::const_iterator & Diccionario::const_iterator::operator ++(){
  ++it;
}
typename Diccionario::const_iterator & Diccionario::const_iterator::operator --(){
  --it;
}
bool Diccionario::const_iterator::operator== (const const_iterator &i) const{
  return i.it == it;
}
bool Diccionario::const_iterator::operator!= (const const_iterator &i) const{
  return i.it != it;
}
*/

typename Diccionario::iterator Diccionario::begin(){
  iterator i;
  i.it = datos.begin();

  return i;
}

typename Diccionario::iterator Diccionario::end(){
  iterator i;
  i.it = datos.end();

  return i;
}

Diccionario::const_iterator Diccionario::begin() const{
    return datos.begin();
}

Diccionario::const_iterator Diccionario::end() const{
    return datos.end();
}

istream& operator>>(istream &is, Diccionario &d){
    string aux;
    while(is.peek()!=EOF){
        is>>aux;
        d.datos.insert(aux);
    }
    return is;
}

ostream &operator<<(ostream &os, const Diccionario &D){
  set<string>::const_iterator it;

  for(it = D.datos.begin(); it != D.datos.end(); ++it){
    os << (*it) << endl;
  }

  return os;
}
