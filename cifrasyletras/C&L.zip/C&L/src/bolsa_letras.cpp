#include <stdlib.h>
#include <cassert>
#include <string>
#include "bolsa_letras.h"

Bolsa_Letras::Bolsa_Letras(){
}

Bolsa_Letras::Bolsa_Letras(const Bolsa_Letras &orig){
    bolsa = orig.bolsa;
}

void Bolsa_Letras::Liberar(){
    bolsa.clear();
}

Bolsa_Letras::~Bolsa_Letras(){
    Liberar();
}

Bolsa_Letras &Bolsa_Letras::operator=(const Bolsa_Letras &otro){
    if(this != &otro){
        bolsa = otro.bolsa;
    }

    return *this;
}

void Bolsa_Letras::aniadirABolsa(Conjunto_Letras &conj){
    Conjunto_Letras::iterator it;

    for(it = conj.begin(); it != conj.end(); ++it){
        for(int i=0; i<(*it).getNumApariciones(); i++)
            bolsa.push_back((*it).getCaracter());
    }
}

string Bolsa_Letras::sacaLetras(int n){
    assert(n<=bolsa.size());
    char out[n];
    int aux;
    for(int i=0; i<n; i++){
        srand(time(NULL));
        aux=rand()%bolsa.size();
        out[i]=bolsa[aux];
        bolsa.erase(bolsa.begin()+aux);
    }
    out[n]='\0';
    return string(out);
}

