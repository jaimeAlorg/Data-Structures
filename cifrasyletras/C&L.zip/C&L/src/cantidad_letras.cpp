#include "diccionario.h"
#include "conjunto_letras.h"
#include <fstream>
#include <string>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    Diccionario dic;
    Conjunto_Letras conj;
    int total = 0, pt, nap;
    char caracter;

    Conjunto_Letras::iterator it;
    

    if (argc != 4)
    {
        cerr << "ERROR: ./cantidad_letras <diccionario> <letras> <fsalida>" << endl;
        return -1;
    }

    ifstream f1(argv[1]);

    if (!f1)
    {
        cerr << "\nNo se puede abrir el fichero diccionario" << endl;
        return -1;
    }

    cout << "\nCargando Diccionario Introducido" << endl;
    f1 >> dic;

    ifstream f2(argv[2]);

    if (!f2)
    {
        cerr << "\nNo se puede abrir el fichero letras" << endl;
        return -1;
    }

    cout << "\nCargando Fichero Letras Introducido" << endl;
    f2 >> conj;

    ofstream f3(argv[3]);
    if (!f3){
      cout << "No se abrir el fichero de salida" << endl;
      return -1;
   }

    for (it = conj.begin(); it != conj.end(); ++it)
    {
        total += (*it).getNumApariciones();
    }

    f3 << "#Letra Cantidad Puntos" << endl;
    for (it = conj.begin(); it != conj.end(); ++it)
    {
        caracter = (*it).getCaracter();
        nap = (*it).getNumApariciones();
        pt = (*it).getPuntuacion();

        f3 << caracter << "\t";
        f3 << nap << "\t";
        f3 << pt << "\t" << endl;
    }

    return 0;
}

