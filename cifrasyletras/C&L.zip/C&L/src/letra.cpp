#include "letra.h"

Letra::Letra(){
    caracter = '0';
    num_apariciones = 0;
    puntuacion = 0;
}

Letra::Letra(char c, int n, int p){
    caracter = c;
    num_apariciones = n;
    puntuacion = p;
}

Letra::Letra(const Letra &orig){
    caracter = orig.caracter;
    num_apariciones = orig.num_apariciones;
    puntuacion = orig.puntuacion;
}

void Letra::Liberar(){
    caracter = '~';
    num_apariciones = 0;
    puntuacion = 0;
}

Letra::~Letra(){
    Liberar();
}

Letra &Letra::operator=(const Letra &orig){
    if(this != &orig){
        Liberar();

        caracter = orig.caracter;
        num_apariciones = orig.num_apariciones;
        puntuacion = orig.puntuacion;
    }

    return *this;
}

char Letra::getCaracter()const{
    return caracter;
}

int Letra::getNumApariciones()const{
    return num_apariciones;
}

int Letra::getPuntuacion()const{
    return puntuacion;
}

void Letra::setCaracter(char c){
    caracter = c;
}

void Letra::setNumApariciones(int n){
    num_apariciones = n;
}

void Letra::setPuntuacion(int p){
    puntuacion = p;
}

bool Letra::operator<(const Letra &l)const{
    return (this->caracter < l.caracter);
}

istream& operator>>(istream &is, Letra &otro){
    is >> otro.caracter >> otro.num_apariciones >> otro.puntuacion;
    return is;
}

ostream& operator<<(ostream &os, const Letra &orig){
    os << "\nLetra: " << orig.caracter << " Cantidad: " << orig.num_apariciones << " Puntos: " << orig.puntuacion << endl;
  return os;
}