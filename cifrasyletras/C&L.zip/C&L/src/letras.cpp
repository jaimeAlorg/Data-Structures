#include "bolsa_letras.h"
#include "diccionario.h"
#include <fstream>
#include <string>
#include <vector>
#include <iostream>

using namespace std;

int main(int argc, char *argv[]){
    Diccionario diccionario;
    Conjunto_Letras conj;
    Bolsa_Letras bolsa;
    char resp = 'S';
    char modo = *argv[4];
    string sol_usr, sol_ord;
    int pt, numl = atoi(argv[3]);

    if(argc != 5){
        cerr << "ERROR. ./letras <fichero diccionario> <fichero letras> <numero letras> <modalidad>" << endl;
        return 0;
    }

    ifstream f1(argv[1]);

    if(!f1){
        cerr << "\nNo se puede abrir el fichero diccionario " << argv[1] << endl;
        return 0;
    }

    cout << "\nCargando Diccioanrio Introducido" << endl;
    f1 >> diccionario;

    ifstream f2(argv[2]);

    if(!f2){
        cerr << "\nNo se puede abrir el fichero letras " << argv[1] << endl;
        return 0;
    }

    cout << "\nCargando Fichero Letras Introducido" << endl;
    f2 >> conj;

    bolsa.aniadirABolsa(conj);

    while(resp == 'S'){
        if(strcmp(argv[4], "P")==0){
            Conjunto_Letras::const_iterator it;

            cout << "******Puntuaciones Letras*******" << endl;
            for(it = conj.begin(); it != conj.end(); ++it){
                cout<<(*it).getCaracter()<<"\t"<<(*it).getPuntuacion()<<endl;
            }
        }

        string l = bolsa.sacaLetras(numl);
        cout << "\nLAS LETRAS SON: " << l << endl;

        for(int i = 0; i < numl ; i++){
            l[i] = tolower(l[i]);
        }

        cout << "\nDime tu solución: " << endl;
        cin >> sol_usr;

        if(diccionario.Esta(sol_usr) && conj.Correcta(sol_usr, l)){
            if(strcmp(argv[4], "P")==0){
                pt = conj.calculaPuntos(sol_usr, conj);
            }else{
                pt = sol_usr.size();
            }
        }else{
            cout << "\nSOLUCIÓN INCORRECTA: 0 PUNTOS " <<endl;
            pt = 0;
        }

        cout << "\n" << sol_usr << " Putuación: " << pt; 
        cout << endl;
        cout << "\nMis soluciones son: " << endl;

        if(strcmp(argv[4], "P")==0){
            sol_ord = conj.generarSolPT(diccionario, l, numl, conj);
        }else{
            sol_ord = conj.generarSolL(diccionario, l, numl);
        }

        cout << "\nMejor Solución: " << sol_ord << endl;

        cout << "¿QUIERES SEGUIR JUGADNO [S/N]? (MAYUSCULAS)" << endl;
        cin >> resp;     
    }
}
